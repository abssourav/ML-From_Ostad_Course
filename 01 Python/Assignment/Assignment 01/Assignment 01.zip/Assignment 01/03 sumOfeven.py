sum = 0
for i in range(1,101):
    if(i%2==0):
        sum = sum + i

print(f"The sum of even numbers between 1 to 100 is : {sum}")